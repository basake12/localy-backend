from pydantic import BaseModel, ConfigDict, computed_field
from typing import Optional, List
from uuid import UUID
from datetime import datetime
from decimal import Decimal

from app.models.subscription_model import (
    SubscriptionPlanTypeEnum,
    BillingCycleEnum,
    SubscriptionStatusEnum,
)

# ─── Tier rank map (used by Flutter SubscriptionGate logic) ─────────────
_TIER_RANK: dict[str, int] = {
    "free": 0,
    "starter": 1,
    "pro": 2,
    "enterprise": 3,
    "pro_driver": 1,
}


class SubscriptionPlanOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: UUID
    plan_type: SubscriptionPlanTypeEnum
    name: str
    monthly_price: Decimal
    annual_price: Decimal
    features: List[str]
    is_active: bool
    created_at: datetime
    updated_at: datetime

    @computed_field
    @property
    def tier(self) -> int:
        """Integer tier rank: 0=free, 1=starter, 2=pro, 3=enterprise."""
        return _TIER_RANK.get(self.plan_type.value, 0)


class SubscriptionCreate(BaseModel):
    plan_id: UUID
    billing_cycle: BillingCycleEnum
    payment_method: str = "wallet"


class SubscriptionUpgrade(BaseModel):
    new_plan_id: UUID
    billing_cycle: BillingCycleEnum
    payment_method: str = "wallet"


class SubscriptionOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: UUID
    user_id: UUID
    plan_id: UUID
    billing_cycle: BillingCycleEnum
    status: SubscriptionStatusEnum
    started_at: datetime
    expires_at: datetime
    auto_renew: bool
    cancelled_at: Optional[datetime] = None
    created_at: datetime
    updated_at: datetime

    # Nested plan — Flutter reads plan details from here
    plan: Optional[SubscriptionPlanOut] = None

    @computed_field
    @property
    def plan_name(self) -> str:
        """Convenience field — Flutter reads this directly."""
        return self.plan.name if self.plan else ""

    @computed_field
    @property
    def amount(self) -> Decimal:
        """Current period charge based on billing cycle."""
        if not self.plan:
            return Decimal("0")
        return (
            self.plan.monthly_price
            if self.billing_cycle == BillingCycleEnum.MONTHLY
            else self.plan.annual_price
        )

    @computed_field
    @property
    def tier(self) -> int:
        """Resolved tier rank of the active plan."""
        if not self.plan:
            return 0
        return _TIER_RANK.get(self.plan.plan_type.value, 0)


class SubscriptionCancelRequest(BaseModel):
    reason: Optional[str] = None


class AutoRenewToggle(BaseModel):
    auto_renew: bool