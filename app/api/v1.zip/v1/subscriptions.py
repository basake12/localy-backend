from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session
from typing import List

from app.core.database import get_db
from app.dependencies import get_current_active_user
from app.models.user_model import User
from app.schemas.subscription_schema import (
    SubscriptionPlanOut,
    SubscriptionOut,
    SubscriptionCreate,
    SubscriptionUpgrade,
    SubscriptionCancelRequest,
    AutoRenewToggle,
)
from app.schemas.common_schema import SuccessResponse, PaginatedResponse
from app.services.subscription_service import subscription_service
from app.core.exceptions import NotFoundException, ValidationException, ForbiddenException

router = APIRouter()


def _require_business(user: User) -> None:
    """Raise 403 if the user is not a business account."""
    if user.user_type != "business":
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Only business accounts can manage subscriptions",
        )


# ─── Plans (public — no auth required) ────────────────────────────────────

@router.get("/plans", response_model=SuccessResponse[List[SubscriptionPlanOut]])
def get_subscription_plans(db: Session = Depends(get_db)):
    """Return all active subscription plans ordered by price."""
    plans = subscription_service.get_available_plans(db)
    return {"success": True, "data": plans}


# ─── My subscription ────────────────────────────────────────────────────────

@router.get("/my-subscription", response_model=SuccessResponse[SubscriptionOut])
def get_my_subscription(
    db: Session = Depends(get_db),
    user: User = Depends(get_current_active_user),
):
    """Return the authenticated business user's current active subscription."""
    _require_business(user)
    try:
        subscription = subscription_service.get_user_subscription(db, user_id=user.id)
        return {"success": True, "data": subscription}
    except NotFoundException as exc:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=exc.detail)


# ─── Subscribe ──────────────────────────────────────────────────────────────

@router.post(
    "/subscribe",
    response_model=SuccessResponse[SubscriptionOut],
    status_code=status.HTTP_201_CREATED,
)
def subscribe_to_plan(
    payload: SubscriptionCreate,
    db: Session = Depends(get_db),
    user: User = Depends(get_current_active_user),
):
    """
    Subscribe a business to a plan.

    - **plan_id**: UUID of the target plan
    - **billing_cycle**: `monthly` or `annual`
    - **payment_method**: `wallet` (card must be pre-funded via Paystack separately)
    """
    _require_business(user)
    try:
        subscription = subscription_service.subscribe(
            db,
            user_id=user.id,
            plan_id=payload.plan_id,
            billing_cycle=payload.billing_cycle,
            payment_method=payload.payment_method,
        )
        return {"success": True, "data": subscription}
    except NotFoundException as exc:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=exc.detail)
    except ValidationException as exc:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=exc.detail)


# ─── Upgrade / downgrade ───────────────────────────────────────────────────

@router.post("/upgrade", response_model=SuccessResponse[SubscriptionOut])
def upgrade_subscription(
    payload: SubscriptionUpgrade,
    db: Session = Depends(get_db),
    user: User = Depends(get_current_active_user),
):
    """
    Upgrade or downgrade the current subscription.

    Per Blueprint:
    - **Upgrade**: immediate, prorated charge applied.
    - **Downgrade**: takes effect at end of billing cycle — active features
      remain until then (handled by `cancel` + re-subscribe on expiry).
    """
    _require_business(user)
    try:
        subscription = subscription_service.upgrade_subscription(
            db,
            user_id=user.id,
            new_plan_id=payload.new_plan_id,
            billing_cycle=payload.billing_cycle,
            payment_method=payload.payment_method,
        )
        return {"success": True, "data": subscription}
    except NotFoundException as exc:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=exc.detail)
    except ValidationException as exc:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=exc.detail)
    except ForbiddenException as exc:
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail=exc.detail)


# ─── Cancel ─────────────────────────────────────────────────────────────────

@router.post("/cancel", response_model=SuccessResponse[SubscriptionOut])
def cancel_subscription(
    payload: SubscriptionCancelRequest,
    db: Session = Depends(get_db),
    user: User = Depends(get_current_active_user),
):
    """
    Cancel the current subscription.
    Access to paid features continues until the billing period ends.
    """
    _require_business(user)
    try:
        subscription = subscription_service.get_user_subscription(db, user_id=user.id)
        cancelled = subscription_service.cancel_subscription(
            db,
            subscription_id=subscription.id,
            user_id=user.id,
        )
        return {"success": True, "data": cancelled}
    except NotFoundException as exc:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=exc.detail)
    except ValidationException as exc:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=exc.detail)


# ─── Toggle auto-renew ──────────────────────────────────────────────────────

@router.patch("/auto-renew", response_model=SuccessResponse[SubscriptionOut])
def toggle_auto_renew(
    payload: AutoRenewToggle,
    db: Session = Depends(get_db),
    user: User = Depends(get_current_active_user),
):
    """Enable or disable automatic renewal for the current subscription."""
    _require_business(user)
    try:
        subscription = subscription_service.get_user_subscription(db, user_id=user.id)
        updated = subscription_service.toggle_auto_renew(
            db,
            subscription_id=subscription.id,
            auto_renew=payload.auto_renew,
        )
        return {"success": True, "data": updated}
    except NotFoundException as exc:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=exc.detail)


# ─── History ─────────────────────────────────────────────────────────────────

@router.get("/history", response_model=SuccessResponse[List[SubscriptionOut]])
def get_subscription_history(
    skip: int = 0,
    limit: int = 20,
    db: Session = Depends(get_db),
    user: User = Depends(get_current_active_user),
):
    """Return paginated subscription history for the authenticated business."""
    _require_business(user)
    subscriptions, total = subscription_service.get_subscription_history(
        db, user_id=user.id, skip=skip, limit=limit
    )
    return {
        "success": True,
        "data": subscriptions,
        "meta": {"total": total, "skip": skip, "limit": limit},
    }