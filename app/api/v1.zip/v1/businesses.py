"""
app/api/v1/businesses.py

FIX (Blueprint v2.0):
  - list_businesses now accepts latitude/longitude/radius_meters instead of
    local_government/state. Discovery is purely GPS-radius based (PostGIS
    ST_DWithin). LGA/state filter params were silently crashing the endpoint
    because search_businesses() never accepted those kwargs.

  - Added per-business stats and analytics endpoints required by the
    Flutter dashboard screens:
      GET /businesses/{id}/stats          → DashboardStats
      GET /businesses/{id}/analytics/revenue → List[RevenuePoint]
"""

from datetime import datetime, timezone, timedelta
from uuid import UUID
from typing import Optional, List

from fastapi import APIRouter, Depends, Query, HTTPException, status
from sqlalchemy import func, and_
from sqlalchemy.orm import Session

from app.core.database import get_db
from app.core.constants import DEFAULT_RADIUS_METERS, MAX_RADIUS_METERS, MIN_RADIUS_METERS
from app.dependencies import get_current_active_user, require_business
from app.models.user_model import User
from app.models.business_model import Business
from app.models.food_model import FoodOrder, Restaurant
from app.models.reviews_model import Review
from app.schemas.business_schema import BusinessOut, BusinessUpdate, BusinessListOut
from app.schemas.common_schema import SuccessResponse
from app.crud.business_crud import business_crud

router = APIRouter()


# ─── Helpers ──────────────────────────────────────────────────────────────────

def _now() -> datetime:
    return datetime.now(timezone.utc)


def _period_days(period: str) -> int:
    mapping = {"7d": 7, "14d": 14, "30d": 30, "90d": 90, "1y": 365}
    return mapping.get(period, 30)


def _get_business_or_404(db: Session, business_id: str) -> Business:
    try:
        uid = UUID(business_id)
    except ValueError:
        raise HTTPException(
            status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
            detail="Invalid business ID",
        )
    business = business_crud.get(db, id=uid)
    if not business or not business.is_active:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Business not found",
        )
    return business


# ─── My Business ──────────────────────────────────────────────────────────────

@router.get("/my-business", response_model=SuccessResponse[BusinessOut])
def get_my_business(
    db: Session = Depends(get_db),
    user: User = Depends(require_business),
):
    """Get the authenticated business user's own profile."""
    business = business_crud.get_by_user_id(db, user_id=user.id)
    if not business:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="No business profile found for this account",
        )
    return {"success": True, "data": business}


@router.put("/my-business", response_model=SuccessResponse[BusinessOut])
def update_my_business(
    payload: BusinessUpdate,
    db: Session = Depends(get_db),
    user: User = Depends(require_business),
):
    """Update the authenticated business user's own profile."""
    business = business_crud.get_by_user_id(db, user_id=user.id)
    if not business:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="No business profile found for this account",
        )
    updated = business_crud.update(db, db_obj=business, obj_in=payload)
    return {"success": True, "data": updated}


# ─── Business Stats ───────────────────────────────────────────────────────────

@router.get("/{business_id}/stats")
def get_business_stats(
    business_id: str,
    period: str = Query("30d", description="Time window: 7d|14d|30d|90d|1y"),
    db: Session = Depends(get_db),
    _: User = Depends(get_current_active_user),
) -> dict:
    """
    Dashboard KPI stats for a business.

    Computed from food_orders for FOOD businesses.
    Returns zeros for other categories (no other order tables wired yet).
    """
    business = _get_business_or_404(db, business_id)
    days = _period_days(period)
    now  = _now()
    since = now - timedelta(days=days)
    prev  = since - timedelta(days=days)

    total_revenue   = 0.0
    prev_revenue    = 0.0
    total_orders    = 0
    prev_orders     = 0
    pending_orders  = 0
    today_revenue   = 0.0

    category_val = (
        business.category.value
        if hasattr(business.category, "value")
        else str(business.category)
    ).upper()

    if category_val == "FOOD":
        restaurant = (
            db.query(Restaurant)
            .filter(Restaurant.business_id == business.id)
            .first()
        )
        if restaurant:
            rid = restaurant.id

            cur = (
                db.query(func.count(FoodOrder.id), func.sum(FoodOrder.total_amount))
                .filter(
                    and_(
                        FoodOrder.restaurant_id == rid,
                        FoodOrder.payment_status == "paid",
                        FoodOrder.created_at >= since,
                    )
                )
                .first()
            )
            total_orders  = cur[0] or 0
            total_revenue = float(cur[1] or 0)

            prv = (
                db.query(func.count(FoodOrder.id), func.sum(FoodOrder.total_amount))
                .filter(
                    and_(
                        FoodOrder.restaurant_id == rid,
                        FoodOrder.payment_status == "paid",
                        FoodOrder.created_at >= prev,
                        FoodOrder.created_at < since,
                    )
                )
                .first()
            )
            prev_orders  = prv[0] or 0
            prev_revenue = float(prv[1] or 0)

            pending_orders = (
                db.query(func.count(FoodOrder.id))
                .filter(
                    and_(
                        FoodOrder.restaurant_id == rid,
                        FoodOrder.order_status.in_(["pending", "confirmed", "preparing"]),
                    )
                )
                .scalar()
                or 0
            )

            today_start = now.replace(hour=0, minute=0, second=0, microsecond=0)
            today_revenue = float(
                db.query(func.sum(FoodOrder.total_amount))
                .filter(
                    and_(
                        FoodOrder.restaurant_id == rid,
                        FoodOrder.payment_status == "paid",
                        FoodOrder.created_at >= today_start,
                    )
                )
                .scalar()
                or 0
            )

    total_customers = total_orders
    prev_customers  = prev_orders

    review_row = (
        db.query(func.count(Review.id), func.avg(Review.rating))
        .filter(Review.reviewable_id == str(business.id))
        .first()
    )
    review_count   = review_row[0] or 0
    average_rating = float(review_row[1] or business.average_rating or 0)

    def _pct(cur: float, prv: float) -> float:
        if prv == 0:
            return 100.0 if cur > 0 else 0.0
        return round((cur - prv) / prv * 100, 1)

    return {
        "success": True,
        "data": {
            "total_revenue":     total_revenue,
            "revenue_change":    _pct(total_revenue, prev_revenue),
            "total_orders":      total_orders,
            "orders_change":     _pct(total_orders, prev_orders),
            "total_customers":   total_customers,
            "customers_change":  _pct(total_customers, prev_customers),
            "average_rating":    average_rating,
            "review_count":      review_count,
            "pending_orders":    pending_orders,
            "today_revenue":     today_revenue,
            "occupancy_rate":        0,
            "occupancy_rate_change": 0,
            "adr":                   0,
            "adr_change":            0,
            "rev_par":               0,
            "rev_par_change":        0,
        },
    }


# ─── Business Analytics — Revenue Chart ───────────────────────────────────────

@router.get("/{business_id}/analytics/revenue")
def get_business_revenue(
    business_id: str,
    period: str = Query("30d", description="7d|14d|30d|90d"),
    db: Session = Depends(get_db),
    _: User = Depends(get_current_active_user),
) -> dict:
    """Daily revenue chart data for the dashboard."""
    business = _get_business_or_404(db, business_id)
    days = _period_days(period)
    now  = _now()

    category_val = (
        business.category.value
        if hasattr(business.category, "value")
        else str(business.category)
    ).upper()

    points: List[dict] = []

    if category_val == "FOOD":
        restaurant = (
            db.query(Restaurant)
            .filter(Restaurant.business_id == business.id)
            .first()
        )
        if restaurant:
            rows = (
                db.query(
                    func.date(FoodOrder.created_at).label("day"),
                    func.sum(FoodOrder.total_amount).label("revenue"),
                )
                .filter(
                    and_(
                        FoodOrder.restaurant_id == restaurant.id,
                        FoodOrder.payment_status == "paid",
                        FoodOrder.created_at >= now - timedelta(days=days),
                    )
                )
                .group_by(func.date(FoodOrder.created_at))
                .order_by(func.date(FoodOrder.created_at))
                .all()
            )
            points = [
                {"label": str(row.day), "amount": float(row.revenue or 0)}
                for row in rows
            ]

    if not points:
        points = [
            {
                "label": (now - timedelta(days=i)).strftime("%m/%d"),
                "amount": 0.0,
            }
            for i in range(min(days, 7), 0, -1)
        ]

    return {"success": True, "data": {"points": points}}


# ─── Business Subscription ────────────────────────────────────────────────────

@router.get("/{business_id}/subscription")
def get_business_subscription(
    business_id: str,
    db: Session = Depends(get_db),
    _: User = Depends(get_current_active_user),
) -> dict:
    """Return the business's active subscription plan."""
    business = _get_business_or_404(db, business_id)

    from app.models.subscription_model import Subscription
    sub = (
        db.query(Subscription)
        .join(User, User.id == Subscription.user_id)
        .join(Business, Business.user_id == User.id)
        .filter(
            and_(
                Business.id == business.id,
                Subscription.status == "ACTIVE",
            )
        )
        .order_by(Subscription.expires_at.desc())
        .first()
    )

    plan_name  = "Free"
    is_active  = False
    expires_at = None

    if sub:
        plan_name  = sub.plan.name if sub.plan else "Starter"
        is_active  = True
        expires_at = sub.expires_at.isoformat() if sub.expires_at else None

    return {
        "success": True,
        "data": {
            "plan_name":  plan_name,
            "is_active":  is_active,
            "expires_at": expires_at,
        },
    }


# ─── Business Inbox ───────────────────────────────────────────────────────────

@router.get("/{business_id}/inbox")
def get_business_inbox(
    business_id: str,
    skip: int = 0,
    limit: int = 20,
    db: Session = Depends(get_db),
    _: User = Depends(get_current_active_user),
) -> dict:
    """Return recent conversations for the business inbox widget."""
    business = _get_business_or_404(db, business_id)

    from app.models.chat_model import Conversation
    convos = (
        db.query(Conversation)
        .filter(Conversation.user_two_id == business.user_id)
        .order_by(Conversation.last_message_at.desc())
        .offset(skip)
        .limit(limit)
        .all()
    )

    messages = []
    for c in convos:
        messages.append({
            "id":          str(c.id),
            "sender_name": "Customer",
            "preview":     c.last_message_preview or "",
            "time":        c.last_message_at.isoformat() if c.last_message_at else _now().isoformat(),
            "unread":      c.unread_count_user_two or 0,
            "avatar_url":  None,
        })

    return {"success": True, "data": {"messages": messages}}


# ─── List / Search Businesses ─────────────────────────────────────────────────
#
# FIX: Blueprint §3 — "Location is radius-based (default 5 km). No LGA filtering."
# The old endpoint accepted local_government/state and passed them to
# search_businesses() which never accepted those params → runtime TypeError.
# Now accepts latitude/longitude/radius_meters; lat+lng are required so the
# caller knows they must send coordinates, matching the Flutter discovery flow.

@router.get("", response_model=SuccessResponse[BusinessListOut])
def list_businesses(
    latitude: float = Query(..., ge=-90, le=90, description="User's current latitude"),
    longitude: float = Query(..., ge=-180, le=180, description="User's current longitude"),
    radius_meters: float = Query(
        DEFAULT_RADIUS_METERS,
        ge=MIN_RADIUS_METERS,
        le=MAX_RADIUS_METERS,
        description="Search radius in metres (default 5 000 m = 5 km)",
    ),
    category: Optional[str] = Query(None),
    search: Optional[str] = Query(None),
    skip: int = Query(0, ge=0),
    limit: int = Query(20, ge=1, le=100),
    db: Session = Depends(get_db),
):
    """
    Discover businesses near the user.

    Sorted by: subscription tier → featured → rating → distance.
    No LGA/state filtering per Blueprint v2.0.
    """
    businesses, total = business_crud.search_businesses(
        db,
        latitude=latitude,
        longitude=longitude,
        radius_meters=radius_meters,
        category=category,
        search_query=search,
        skip=skip,
        limit=limit,
    )
    return {
        "success": True,
        "data": {
            "businesses": businesses,
            "total":      total,
            "page":       skip // limit + 1,
            "page_size":  limit,
        },
    }


# ─── Get Business By ID ───────────────────────────────────────────────────────

@router.get("/{business_id}", response_model=SuccessResponse[BusinessOut])
def get_business_by_id(
    business_id: str,
    db: Session = Depends(get_db),
    _: User = Depends(get_current_active_user),
):
    """Get any public business profile by ID."""
    business = _get_business_or_404(db, business_id)
    return {"success": True, "data": business}